import os
import shutil
import subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

TOKEN = os.getenv("BOT_TOKEN")

games_list = [
    "Mini Militia",
    "Subway Surfers",
    "Temple Run",
    "Hill Climb Racing",
]

selected_game = {}

def get_games_buttons():
    return [[InlineKeyboardButton(game, callback_data=f"game_{game}")] for game in games_list]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("🎮 تهكير الألعاب", callback_data="hack_games")],
        [InlineKeyboardButton("🔓 فك التشفير", callback_data="decrypt")],
    ]
    await update.message.reply_text("هلا، اختار شنو تريد:", reply_markup=InlineKeyboardMarkup(keyboard))

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "hack_games":
        await query.edit_message_text(
            "اختر اللعبة اللي تريد تهكرها 🔥:", reply_markup=InlineKeyboardMarkup(get_games_buttons())
        )
    elif query.data == "decrypt":
        await query.edit_message_text("ميزة فك التشفير تحت التطوير 🔓.")
    elif query.data.startswith("game_"):
        game_name = query.data.replace("game_", "")
        user_id = query.from_user.id
        selected_game[user_id] = game_name
        await query.edit_message_text(
            f"🔥 اخترت {game_name}\nارسللي APK اللعبة هسه حتى أضيف مود منيو."
        )

async def apk_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id not in selected_game:
        await update.message.reply_text("رجاءً اختار اللعبة أولاً من /start 🎮")
        return

    if not update.message.document:
        await update.message.reply_text("ارسللي ملف APK صحيح.")
        return

    file = await update.message.document.get_file()
    apk_path = f"{user_id}_{selected_game[user_id].replace(' ', '_')}.apk"
    await file.download_to_drive(apk_path)

    await update.message.reply_text("⏳ جاري تعديل اللعبة وإضافة مود منيو... انتظر شوي 🔥")

    hacked_apk = await hack_apk(apk_path)
    if hacked_apk:
        await update.message.reply_document(open(hacked_apk, "rb"))
        os.remove(hacked_apk)
    else:
        await update.message.reply_text("صارت مشكلة أثناء التعديل، جرب مرة ثانية.")

    if os.path.exists(apk_path):
        os.remove(apk_path)

async def hack_apk(apk_path):
    folder = apk_path.replace(".apk", "")
    cmd_decode = ["apktool", "d", apk_path, "-o", folder, "-f"]
    result = subprocess.run(cmd_decode, capture_output=True)
    if result.returncode != 0:
        return None

    smali_dir = os.path.join(folder, "smali")
    mod_smali_dir = "mod_smali"  # مجلد فيه ملفات smali للمود منيو

    if not os.path.exists(mod_smali_dir):
        return None

    for root, dirs, files in os.walk(mod_smali_dir):
        rel_path = os.path.relpath(root, mod_smali_dir)
        dest_dir = os.path.join(smali_dir, rel_path)
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        for file in files:
            shutil.copy(os.path.join(root, file), os.path.join(dest_dir, file))

    hacked_apk_path = apk_path.replace(".apk", "_huby_mod.apk")
    cmd_build = ["apktool", "b", folder, "-o", hacked_apk_path]
    result = subprocess.run(cmd_build, capture_output=True)
    if result.returncode != 0:
        return None

    keystore_path = "debug.keystore"  # لازم ترفع ملف keystore مع المشروع
    cmd_sign = ["apksigner", "sign", "--ks", keystore_path, hacked_apk_path]
    result = subprocess.run(cmd_sign, capture_output=True)
    if result.returncode != 0:
        return None

    shutil.rmtree(folder)
    return hacked_apk_path

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.Document.ALL, apk_handler))
    app.run_polling()

if __name__ == "__main__":
    main()